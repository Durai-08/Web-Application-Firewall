import re
import json
import time
import datetime
from flask import Flask, request, render_template, redirect, url_for, session, jsonify
from werkzeug.utils import secure_filename

# Create the Flask application instance
app = Flask(__name__)
# A secret key is required for sessions. You MUST change this in a real application.
app.secret_key = 'your_super_secret_key_here'

# --- DEMO DATA & SETTINGS ---
PRODUCTS = [
    {"name": "Laptop", "price": 1200},
    {"name": "Mouse", "price": 50},
    {"name": "Keyboard", "price": 75},
    {"name": "Monitor", "price": 300},
]

# Updated USERS dictionary with roles for Role-Based Access Control
USERS = {
    "admin": {"password": "password123", "role": "admin"},
    "testuser": {"password": "testpass", "role": "user"}
}

# --- PERSISTENT LOGGING ---
LOG_FILE = "attack_logs.json"

def load_logs():
    try:
        with open(LOG_FILE, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_logs(logs):
    with open(LOG_FILE, 'w') as f:
        json.dump(logs, f, indent=4)

# Load logs on application startup
ATTACK_LOGS = load_logs()

# --- RATE LIMITING ---
RATE_LIMIT_DURATION = 60
MAX_REQUESTS_PER_MINUTE = 10
REQUEST_HISTORY = {}

# --- FILE UPLOAD SETTINGS ---
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# --- WAF LOGIC: This function runs before every request ---
@app.before_request
def waf_middleware():
    """
    This WAF function checks for rate limiting, malicious payloads, and now, dangerous file extensions.
    """
    user_ip = request.remote_addr
    current_time = time.time()
    
    REQUEST_HISTORY[user_ip] = [
        t for t in REQUEST_HISTORY.get(user_ip, []) 
        if current_time - t < RATE_LIMIT_DURATION
    ]
    
    if len(REQUEST_HISTORY[user_ip]) >= MAX_REQUESTS_PER_MINUTE:
        log_attack("Rate Limit Exceeded", request, 'N/A', 'Too many requests')
        return jsonify({"error": "Rate limit exceeded"}), 429
    
    REQUEST_HISTORY[user_ip].append(current_time)

    # Malicious Payload Patterns
    sqli_pattern = re.compile(r"(\b(OR|AND|UNION|SELECT|INSERT|DELETE|UPDATE|DROP|TRUNCATE)\b|\-\-|\#|\/\*|\')", re.IGNORECASE)
    # Corrected XSS pattern to catch more cases
    xss_pattern = re.compile(r"(<script.*?>|on\w+?=|javascript:)", re.IGNORECASE)
    path_traversal_pattern = re.compile(r"(\.\.\/|\.\.\\|%2e%2e%2f|%2e%2e%5c)", re.IGNORECASE)

    # Check for malicious payloads in form and URL data
    data_to_check = {**request.args, **request.form, 'url': request.path}
    for key, value in data_to_check.items():
        if isinstance(value, str):
            if sqli_pattern.search(value):
                log_attack("SQL Injection", request, key, value)
                return jsonify({"error": "Potential SQL Injection detected"}), 403
            
            if xss_pattern.search(value):
                log_attack("Cross-Site Scripting", request, key, value)
                return jsonify({"error": "Potential Cross-Site Scripting (XSS) detected"}), 403

            if path_traversal_pattern.search(value):
                log_attack("Path Traversal", request, key, value)
                return jsonify({"error": "Potential Path Traversal detected"}), 403

def log_attack(attack_type, req, field, payload):
    """
    Helper function to create and store a log entry.
    It now saves the logs to a file.
    """
    global ATTACK_LOGS
    log_entry = {
        'timestamp': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'attack_type': attack_type,
        'user_ip': req.remote_addr,
        'attacked_field': field,
        'malicious_payload': payload
    }
    ATTACK_LOGS.append(log_entry)
    save_logs(ATTACK_LOGS)
    print(f"SECURITY ALERT: {attack_type} detected from {req.remote_addr} on field '{field}' with payload: '{payload}'")

# --- APPLICATION ROUTES ---

@app.route("/", methods=["GET", "POST"])
def index():
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    search_query = request.form.get("search", "")
    filtered_products = [
        p for p in PRODUCTS if search_query.lower() in p["name"].lower()
    ]
    return render_template("index.html", products=filtered_products)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username in USERS and USERS[username]["password"] == password:
            session['logged_in'] = True
            session['role'] = USERS[username]["role"]
            return redirect(url_for('index'))
        else:
            return render_template("login.html", error="Invalid Credentials. Please try again.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop('logged_in', None)
    session.pop('role', None)
    return redirect(url_for('login'))

@app.route("/logs")
def logs():
    if 'logged_in' not in session or session.get('role') != 'admin':
        return redirect(url_for('login'))
    
    current_logs = load_logs()
    return render_template("logs.html", logs=current_logs)

@app.route("/clear-logs")
def clear_logs():
    if 'logged_in' not in session or session.get('role') != 'admin':
        return redirect(url_for('login'))
    
    global ATTACK_LOGS
    ATTACK_LOGS = []
    save_logs(ATTACK_LOGS)
    return redirect(url_for('logs'))

@app.route("/upload", methods=["GET", "POST"])
def upload_file():
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        
        file = request.files['file']
        
        if file.filename == '':
            return render_template("upload.html", message="No file selected.")

        if not allowed_file(file.filename):
            log_attack("Malicious File Upload", request, 'file', file.filename)
            return render_template("upload.html", message=f"Error: File type '{file.filename.rsplit('.', 1)[1]}' not allowed.")

        filename = secure_filename(file.filename)
        return render_template("upload.html", message=f"File '{filename}' uploaded successfully.")
        
    return render_template("upload.html")

@app.route("/protected/file")
def protected_file():
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    filename = request.args.get("file", "protected_file.txt")
    return f"This is the content of the file: {filename}"

if __name__ == "__main__":
    app.run(debug=True)
